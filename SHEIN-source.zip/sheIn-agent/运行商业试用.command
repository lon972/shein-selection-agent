#!/bin/bash
cd "$(dirname "$0")"
npm run run
status=$?
printf "\n运行结束\n"
printf "状态码：%s\n" "${status}"
if [ "${status}" -eq 0 ]; then
  echo "结果：商业试用门禁通过。"
elif [ "${status}" -eq 2 ]; then
  echo "结果：证据和诊断已保存，但未通过商业门禁。请查看质量校验.json和选品报告.md。"
else
  echo "结果：程序异常，请查看终端错误和运行诊断。"
fi
read -n 1 -s -r -p "按任意键关闭"
exit $status
