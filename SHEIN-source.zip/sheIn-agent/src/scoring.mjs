import { cleanUrl, safeText, sha256 } from './utils.mjs';

const clamp=(v,lo,hi)=>Math.max(lo,Math.min(hi,v));
function num(item,key,lo=-Infinity,hi=Infinity){const v=Number(item?.[key]);return item?.[key]===null||item?.[key]===undefined||item?.[key]===''||!Number.isFinite(v)||v<lo||v>hi?null:v;}
const METRICS={rating:[0,5],review_count:[0,Infinity],sold_recent:[0,Infinity],bestseller_rank:[1,Infinity],trend_growth_pct:[-100,500],competition_count:[0,Infinity],gross_margin_pct:[0,100],lead_days:[1,120],complexity:[1,5],market_fit:[1,5],climate_fit:[1,5],price_fit:[1,5],size_fit:[1,5],modesty_fit:[1,5]};
function quality(item){return Object.entries(METRICS).filter(([k,[a,b]])=>num(item,k,a,b)!==null).length+Number(Boolean(cleanUrl(item.product_url)))+Number(Boolean(item.title))+Number(String(item.verification_status).toLowerCase()==='verified');}
function regional(fields,market){
  const {fit,climate,price,size,modesty}=fields;
  if(market==='土耳其'){
    const values=[[fit,.25],[climate,.20],[price,.25],[size,.15],[modesty,.15]],present=values.filter(([v])=>v!==null);
    return {score:present.reduce((s,[v,w])=>s+v/5*10*w,0),fields:values.map(([v])=>v),missing:values.filter(([v])=>v===null).length};
  }
  const values=[[fit,.4],[climate,.2],[price,.2],[size,.2]],present=values.filter(([v])=>v!==null);
  return {score:present.reduce((s,[v,w])=>s+v/5*10*w,0),fields:values.map(([v])=>v),missing:values.filter(([v])=>v===null).length};
}
function actionFor(score,completeness,decisionGrade){if(!decisionGrade)return'补证后再决策';if(completeness<55)return'补证后再决策';return score>=80?'优先打样':score>=70?'小单测试':score>=60?'观察/补证':'暂不跟进';}

export function scoreOne(item,marketGroup='欧美+土耳其'){
  const rating=num(item,'rating',0,5),reviews=num(item,'review_count',0),sold=num(item,'sold_recent',0),rank=num(item,'bestseller_rank',1);
  let demand=0;if(rating!==null)demand+=rating/5*7;if(reviews!==null)demand+=Math.min(Math.log10(reviews+1)/4,1)*7;if(sold!==null)demand+=Math.min(Math.log10(sold+1)/4,1)*8;if(rank!==null)demand+=clamp((21-rank)/20,0,1)*8;
  const trend=num(item,'trend_growth_pct',-100,500),competition=num(item,'competition_count',0),margin=num(item,'gross_margin_pct',0,100),lead=num(item,'lead_days',1,120),complexity=num(item,'complexity',1,5);
  const trendScore=trend===null?0:clamp((trend+20)/100,0,1)*15,competitionScore=competition===null?0:clamp(1-competition/200,0,1)*15,marginScore=margin===null?0:clamp((margin-15)/40,0,1)*15;
  const supply=(lead===null?0:clamp((30-lead)/25,0,1)*9)+(complexity===null?0:clamp((6-complexity)/5,0,1)*6),base=demand+trendScore+competitionScore+marginScore+supply;
  const fit=num(item,'market_fit',1,5),climate=num(item,'climate_fit',1,5),price=num(item,'price_fit',1,5),size=num(item,'size_fit',1,5),modesty=num(item,'modesty_fit',1,5),regionFields={fit,climate,price,size,modesty};
  const euro=regional(regionFields,'欧美'),turkey=regional(regionFields,'土耳其');
  const baseFields=[rating,reviews,sold,rank,trend,competition,margin,lead,complexity],targets=/土耳其/.test(marketGroup)&&/(欧美|欧洲|北美|美国|英国)/.test(marketGroup)?['欧美','土耳其']:/土耳其/.test(marketGroup)?['土耳其']:['欧美'];
  const targetFields=targets.flatMap(x=>x==='土耳其'?turkey.fields:euro.fields),completeness=Math.round([...baseFields,...targetFields].filter(v=>v!==null).length/(baseFields.length+targetFields.length)*100);
  const url=cleanUrl(item.product_url),linkType=['product','listing','source'].includes(item.link_type)?item.link_type:'source',origin=safeText(item.data_origin||'public_discovery',40),declared=String(item.verification_status||'').toLowerCase();
  const verified=declared==='verified'&&Boolean(item.verified_by)&&Boolean(item.evidence_date),decisionGrade=verified&&['enterprise','manual_verified'].includes(origin)&&linkType==='product'&&Boolean(url)&&completeness>=55;
  const marketScores={欧美:Number((base+euro.score).toFixed(2)),土耳其:Number((base+turkey.score).toFixed(2))},marketActions=Object.fromEntries(Object.entries(marketScores).map(([k,v])=>[k,actionFor(v,completeness,decisionGrade)]));
  const activeScores=targets.map(x=>marketScores[x]),score=Math.max(...activeScores),action=targets.map(x=>marketActions[x]).find(x=>x==='优先打样')||targets.map(x=>marketActions[x]).find(x=>x==='小单测试')||targets.map(x=>marketActions[x]).find(x=>x==='观察/补证')||marketActions[targets[0]];
  const warnings=[];if(!url)warnings.push('无有效链接');if(linkType!=='product')warnings.push('不是商品详情直链');if(!verified)warnings.push('尚未由业务人员核验');if(origin==='public_discovery')warnings.push('公开采集仅用于发现，不作为决策级证据');if(targets.includes('土耳其')&&turkey.missing)warnings.push(`土耳其适配缺少${turkey.missing}项字段`);
  return {...item,title:safeText(item.title||'未命名候选款',300),product_url:url,link_type:linkType,source_market:safeText(item.source_market||'未填写',40),data_origin:origin,verification_status:verified?'verified':'pending',decision_grade:decisionGrade,score,sort_score:score,action,evidence_completeness:completeness,market_scores:marketScores,market_actions:marketActions,recommended_markets:targets.filter(x=>['优先打样','小单测试'].includes(marketActions[x])),score_breakdown:{需求强度:+demand.toFixed(2),趋势增长:+trendScore.toFixed(2),竞争空间:+competitionScore.toFixed(2),毛利:+marginScore.toFixed(2),供应链可做性:+supply.toFixed(2),欧美适配:+euro.score.toFixed(2),土耳其适配:+turkey.score.toFixed(2)},warnings,evidence_id:`E-${sha256(`${url}|${item.title}`).slice(0,10)}`};
}

export function scoreCandidates(items,marketGroup='欧美+土耳其',limit=20){
  const byKey=new Map(),audit=[];
  for(const [i,raw] of (Array.isArray(items)?items:[]).slice(0,100).entries()){
    if(!raw||typeof raw!=='object'||Array.isArray(raw)){audit.push(`第${i+1}项不是对象，已移除`);continue;}
    const key=cleanUrl(raw.product_url)||safeText(raw.title).toLowerCase().replace(/\s/g,'');if(!key){audit.push(`第${i+1}项无标题和有效链接，已移除`);continue;}
    const old=byKey.get(key);if(!old||quality(raw)>quality(old)){if(old)audit.push(`重复候选保留字段更完整记录：${raw.title||key}`);byKey.set(key,raw);}else audit.push(`重复候选已移除：${raw.title||key}`);
  }
  const scored=[...byKey.values()].map(x=>scoreOne(x,marketGroup)).sort((a,b)=>Number(b.decision_grade)-Number(a.decision_grade)||b.sort_score-a.sort_score||b.evidence_completeness-a.evidence_completeness).slice(0,clamp(Number(limit)||20,1,50));
  return {scored,audit,decisionGradeCount:scored.filter(x=>x.decision_grade).length,discoveryCount:scored.filter(x=>!x.decision_grade).length};
}
