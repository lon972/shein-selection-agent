function link(item){return item.product_url?`[打开参考](${item.product_url})`:'无有效链接';}
export function rankingTable(items){const lines=['|排名|候选款|参考链接|证据状态|欧美分|土耳其分|完整度|动作|','|---:|---|---|---|---:|---:|---:|---|'];items.forEach((x,i)=>lines.push(`|${i+1}|${String(x.title).replaceAll('|','｜')}|${link(x)}|${x.decision_grade?'决策级':'发现/待核验'}|${x.market_scores?.欧美??x.score}|${x.market_scores?.土耳其??x.score}|${x.evidence_completeness}%|${x.action}|`));return lines.join('\n');}
export function evidenceFallback({runId,cfg,items,sourceRecords,diagnostics,blockReason='写作或商业门禁未完成'}){
  const usable=items.filter(x=>x.evidence_completeness>=cfg.minEvidenceCompleteness&&['优先打样','小单测试'].includes(x.action));
  return `# SHEIN女装选品与跟版决策报告

> 交付状态：${blockReason}；本文件为确定性选品工作台报告，不可作为商业终稿。\n> run_id：${runId}｜P3 V1.1.0｜${cfg.marketGroup}｜${new Date().toISOString()}

## 1. 本轮结论

共保留${items.length}个候选，其中决策级${items.filter(x=>x.decision_grade).length}个、公开发现/待核验${items.filter(x=>!x.decision_grade).length}个，达到内部打样/小单讨论动作${usable.length}个。本轮不把公开采集失败解释为市场无款，也不把发现级链接提升为打样结论。评分表、欧美/土耳其分市场结果、链接和补数清单仍可用于团队完成下一轮确定性输入。

## 2. 候选款排序

${rankingTable(items)}

## 3. Top候选逐款决策卡

${items.slice(0,5).map(x=>`### ${x.title}\n- 欧美/土耳其：${x.market_scores?.欧美??'未评分'} / ${x.market_scores?.土耳其??'未评分'}\n- 分项：${Object.entries(x.score_breakdown||{}).map(([k,v])=>`${k}${v}`).join('；')}\n- 证据状态：${x.decision_grade?'决策级':'发现/待核验'}；${x.data_origin||'来源未标注'}\n- 证据：${x.evidence_note||'未提供'}\n- 限制：${x.warnings?.join('；')||'无额外警告'}\n- 原链接：${x.product_url||'无有效链接'}`).join('\n\n')||'当前没有候选款。请先在input/candidates.csv填入至少3个已人工打开核验的商品详情链接，并填写verified_by、evidence_date、工厂毛利和交期。'}

## 4. 区域化跟版设计Brief

商业门禁未完成时，禁止用通用模板冒充逐款Brief。人工复核时应记录版型、长度、领型、袖型、面料、颜色、尺码覆盖、端庄度、工艺复杂度、预计成本和交期；欧美与土耳其分别填写climate_fit、price_fit、size_fit，土耳其另外核对modesty_fit。没有图片与工艺证据时不得自动填写，也不得复制商标、图案、模特图或独特装饰组合。

## 5. 小单验证方案

建议记录上架后3/7/14/30日曝光、点击、加购、订单、毛利、退货、尺码投诉和补单时长；阈值须依据企业历史基线确认。没有历史基线时先收集样本，不把通用百分比写成企业止损线。每次打样、上架、改版、补单或淘汰均记录负责人、日期和依据，以便后续回测评分权重。

## 6. 暂不跟进与淘汰原因

${items.filter(x=>!['优先打样','小单测试'].includes(x.action)).map(x=>`- ${x.title}：${x.action}，完整度${x.evidence_completeness}%`).join('\n')||'无。'}

## 7. 补数清单

- 在input/candidates.csv至少填写3个商品详情直链；\n- 人工打开链接后填写verification_status=verified、data_origin=manual_verified、verified_by和evidence_date；\n- 补齐销量/评价/趋势/毛利/交期，以及欧美/土耳其适配字段；\n- listing/source只能保留为发现线索，不能变成决策级候选；\n- 若只是Dify失败，保留采集与评分文件并重试写作，不必重新采集。

## 8. 来源索引

${sourceRecords.map(x=>`- ${x.name}｜${x.status}/${x.coverage_status||'状态未细分'}｜${x.capturedAt}｜${x.url}｜提取:${(x.extraction_methods||[]).join(',')||'无'}｜${x.error||'无错误'}`).join('\n')||'- 本轮未启用公开来源；这不代表市场数量为0。'}

## 9. 责任边界

本报告用于降低筛选与试错成本，不保证销量。大货前必须结合真实订单、退货、尺码投诉、毛利和补单能力。

### 运行诊断
${diagnostics.map(x=>`- ${x}`).join('\n')||'- 无'}
`;
}

export function mockCommercialReport({runId,cfg,items,sourceRecords}){
  const top=items.slice(0,3);return `# SHEIN女装选品与跟版决策报告

> 商业试用测试报告｜run_id：${runId}｜P3 V1.1.0｜${cfg.marketGroup}

## 1. 本轮结论

本轮保留${items.length}款，优先复核${top.length}款。所有动作仍需通过真实毛利、样衣和上架数据确认。评分用于统一内部讨论顺序，不代表销量预测；证据完整度反映当前字段覆盖，不代表来源本身绝对可靠。建议商品、设计、采购和生产共同复核后再进入打样。

## 2. 候选款排序

${rankingTable(items)}

## 3. Top候选逐款决策卡

${top.map(x=>`### ${x.title}\n- 建议动作：${x.action}\n- 欧美/土耳其：${x.market_scores?.欧美??x.score}/${x.market_scores?.土耳其??x.score}\n- 完整度/证据级：${x.evidence_completeness}%/${x.decision_grade?'决策级':'发现级'}\n- 证据：${x.evidence_note||'数据缺失'}\n- 不能推出：公开页面信号不能等同未来销量。\n- 原链接：${x.product_url||'无有效链接'}`).join('\n\n')||'无候选。'}

## 4. 区域化跟版设计Brief

${top.map(x=>`- **${x.title}**：保留已验证的基本版型变量；根据${cfg.marketGroup}调整长度、袖型、领型、面料克重、尺码覆盖与端庄度；不得复制商标、图案和独特装饰组合；成本与交期待工厂复核。设计确认时分别记录“参考变量、主动差异化、工艺风险、成本变化、首样修改点”，避免把参考成品直接等同生产图。`).join('\n')||'无。'}

## 5. 小单验证方案

每款先建立内部样本量和止损线，记录3/7/14/30日曝光、点击、加购、订单、毛利、退货、尺码投诉和补单时长。阈值使用企业历史中位数，不使用通用虚构数值。第3日看曝光与点击是否获得基础反馈，第7日看加购与首批订单，第14日看退货和尺码问题，第30日综合毛利、退货和补单速度决定放量、改版或淘汰。每次状态变化保留负责人、日期和依据。

## 6. 暂不跟进与淘汰原因

${items.slice(3).map(x=>`- ${x.title}：${x.action}，当前完整度${x.evidence_completeness}%。`).join('\n')||'无。'}

## 7. 补数清单

- 逐条打开商品详情直链；\n- 核对站点、日期、排名和近期售出口径；\n- 补齐工厂成本、交期、MOQ和真实毛利；\n- 区分平台公开信号与企业内部成交数据；\n- 土耳其市场补齐气候、价格带、面料透度、长度、袖型、领口和尺码覆盖；\n- 欧美与土耳其分别回填3/7/14/30日结果，为后续权重校准建立样本。

## 8. 来源索引

${sourceRecords.map(x=>`- ${x.name}｜${x.status}｜${x.capturedAt}｜${x.url}`).join('\n')}

## 9. 责任边界

本报告提高候选筛选效率、降低试错成本，不保证销量；大货必须经过样衣、合规、真实订单和毛利复核。公开网页可能因地区、登录状态、AB测试和时间变化而变化；榜单页不能冒充商品直链，标题营销词不能冒充平台排名。任何高分款若缺少成本、交期或真实转化数据，仍只能进入小单验证，不得直接放大备货。商品、设计、采购、生产和销售应分别确认款式差异化、面辅料可得性、首样周期、目标毛利和区域销售反馈；任一关键条件不成立时，保持观察或重新打样，不以模型文字代替负责人审批。
`;}
