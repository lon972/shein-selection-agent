import fs from 'node:fs/promises';

function parseRows(text){
  const rows=[];let row=[],field='',quoted=false;
  for(let i=0;i<text.length;i++){
    const c=text[i];
    if(quoted){if(c==='"'&&text[i+1]==='"'){field+='"';i++;}else if(c==='"')quoted=false;else field+=c;}
    else if(c==='"')quoted=true;else if(c===','){row.push(field);field='';}else if(c==='\n'){row.push(field.replace(/\r$/,''));rows.push(row);row=[];field='';}else field+=c;
  }
  if(field||row.length){row.push(field.replace(/\r$/,''));rows.push(row);}return rows;
}
function convert(value){const text=String(value??'').trim();if(text==='')return null;if(/^-?\d+(?:\.\d+)?$/.test(text))return Number(text);if(/^(true|false)$/i.test(text))return /^true$/i.test(text);return text;}
export function parseCandidatesCsv(text){const rows=parseRows(String(text||'').replace(/^\uFEFF/,''));if(rows.length<2)return[];const headers=rows[0].map(x=>x.trim());return rows.slice(1).filter(row=>row.some(x=>String(x).trim())).map(row=>Object.fromEntries(headers.map((h,i)=>[h,convert(row[i])])));}
export async function loadCandidateInputs(jsonPath,csvPath,{jsonOverride=null}={}){
  const diagnostics=[];let jsonItems=[];let csvItems=[];
  if(jsonOverride!==null)jsonItems=jsonOverride;
  else try{const parsed=JSON.parse(await fs.readFile(jsonPath,'utf8'));if(Array.isArray(parsed))jsonItems=parsed;else diagnostics.push('JSON候选文件不是数组，已忽略');}catch(e){if(e.code!=='ENOENT')diagnostics.push(`JSON候选文件错误:${e.message}`);}
  try{csvItems=parseCandidatesCsv(await fs.readFile(csvPath,'utf8'));}catch(e){if(e.code!=='ENOENT')diagnostics.push(`CSV候选文件错误:${e.message}`);}
  return {items:[...jsonItems,...csvItems],jsonCount:jsonItems.length,csvCount:csvItems.length,diagnostics};
}
