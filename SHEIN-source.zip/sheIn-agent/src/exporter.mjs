import path from 'node:path';
import { csvEscape, ensureDir, writeJson, writeText } from './utils.mjs';
export async function exportRun(cfg,runId,{markdown,items,validation,diagnostics,rejectedModelReport=''}){
  const dir=path.join(cfg.outputDir,runId);await ensureDir(dir);const md=path.join(dir,'选品报告.md');await writeText(md,markdown);
  const html=path.join(dir,'选品报告.html');await writeText(html,`<!doctype html><meta charset="utf-8"><title>SHEIN选品报告</title><style>body{max-width:980px;margin:40px auto;font:16px/1.7 system-ui;padding:0 24px}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:8px}pre{white-space:pre-wrap}</style><pre>${markdown.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')}</pre>`);
  const headers=['evidence_id','title','product_url','link_type','source_market','data_origin','verification_status','decision_grade','score','market_scores','market_actions','evidence_completeness','action','evidence_date','verified_by','evidence_note'];const csv=[headers.join(','),...items.map(x=>headers.map(k=>csvEscape(typeof x[k]==='object'?JSON.stringify(x[k]):x[k])).join(','))].join('\n');await writeText(path.join(dir,'候选款评分.csv'),'\ufeff'+csv);
  if(rejectedModelReport)await writeText(path.join(dir,'model-report-rejected.md'),rejectedModelReport);
  await writeJson(path.join(dir,'候选款证据.json'),items);await writeJson(path.join(dir,'质量校验.json'),{...validation,commercial_ok:validation.passed});await writeJson(path.join(dir,'运行诊断.json'),diagnostics);return {dir,markdownPath:md,htmlPath:html};
}
