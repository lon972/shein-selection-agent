import fs from 'node:fs/promises';
import path from 'node:path';
import { runtimeConfig } from './config.mjs';
import { readJson, makeRunId, writeJson } from './utils.mjs';
import { ROOT } from './paths.mjs';
import { openDatabase, startRun, finishRun, saveSource, saveEvidence, saveReport } from './db.mjs';
import { collectAll } from './collector.mjs';
import { scoreCandidates } from './scoring.mjs';
import { loadCandidateInputs } from './input.mjs';
import { callDify } from './dify.mjs';
import { evidenceFallback, mockCommercialReport, rankingTable } from './report.mjs';
import { validateReport } from './validator.mjs';
import { exportRun } from './exporter.mjs';
import { fitEvidencePack } from './evidence.mjs';

const args=new Set(process.argv.slice(2)),mock=args.has('--mock'),collectOnly=args.has('--collect-only'),cfg=runtimeConfig(),runId=makeRunId(),diagnostics=[],db=openDatabase(cfg.sqlitePath);startRun(db,runId,cfg);
try{
  console.log(`[P3 V1.1.0] run_id=${runId}｜${cfg.performanceMode}｜${cfg.marketGroup}`);
  const sourceConfig=await readJson(cfg.sourceFile,{sources:[]});let records=[];
  if(mock){const [html,json,localFixture]=await Promise.all([fs.readFile(path.join(ROOT,'fixtures','shein-listing.html'),'utf8'),readJson(path.join(ROOT,'fixtures','shein-api.json'),{}),readJson(path.join(ROOT,'fixtures','normal.json'),[])]);records=await collectAll({sources:sourceConfig.sources.slice(0,1)},cfg,{fixtureHtml:html,fixtureJson:json});var localInput=await loadCandidateInputs(cfg.inputFile,cfg.inputCsvFile,{jsonOverride:localFixture});}
  else{records=await collectAll(sourceConfig,cfg);var localInput=await loadCandidateInputs(cfg.inputFile,cfg.inputCsvFile);}
  diagnostics.push(...localInput.diagnostics);
  for(const r of records){saveSource(db,runId,r);console.log(`[采集] ${r.name}：${r.status}/${r.coverage_status}，${r.items.length}项${r.error?`｜${r.error}`:''}`);if(r.status!=='ok')diagnostics.push(`${r.name}:${r.status}/${r.coverage_status}:${r.error||'无商品项'}`);}
  const discovery=records.flatMap(x=>x.items||[]),combined=[...localInput.items,...discovery],scoring=scoreCandidates(combined,cfg.marketGroup,cfg.maxCandidatesToDify),scored=scoring.scored;diagnostics.push(...scoring.audit);saveEvidence(db,runId,scored);
  console.log(`[确定性输入] JSON ${localInput.jsonCount}项｜CSV ${localInput.csvCount}项｜公开发现 ${discovery.length}项｜决策级 ${scoring.decisionGradeCount}项`);
  if(!discovery.length)diagnostics.push('公开发现为0：表示本轮未采到，不表示市场商品数量为0');
  const coverage={local_json:localInput.jsonCount,local_csv:localInput.csvCount,public_discovery:discovery.length,decision_grade:scoring.decisionGradeCount,pending_or_discovery:scoring.discoveryCount,sources:records.map(x=>({id:x.id,status:x.status,coverage_status:x.coverage_status,item_count:x.items.length}))};
  const collectedPath=path.join(cfg.outputDir,runId,'采集与评分.json');await writeJson(collectedPath,{runId,version:'P3 V1.1.0',market_context:{market_group:cfg.marketGroup,target_countries:cfg.targetCountries,category:cfg.category,season:cfg.season,price_band:cfg.priceBand},coverage,records,scored,diagnostics});
  if(collectOnly){finishRun(db,runId,'collected',diagnostics);console.log(`[完成] 仅采集与评分：${collectedPath}`);process.exitCode=0;}
  else{
    let markdown='',rejectedModelReport='',difySucceeded=false,difyMeta={},blockReason='';
    if(mock){markdown=mockCommercialReport({runId,cfg,items:scored,sourceRecords:records});difySucceeded=true;difyMeta={mode:'mock'};}
    else if(scoring.decisionGradeCount<cfg.minDecisionGradeCandidates){blockReason=`决策级候选不足：${scoring.decisionGradeCount}/${cfg.minDecisionGradeCandidates}`;diagnostics.push(blockReason);markdown=evidenceFallback({runId,cfg,items:scored,sourceRecords:records,diagnostics,blockReason});}
    else{
      const evidence={run_id:runId,product_stage:'P3',software_version:'1.1.0',market_context:{market_group:cfg.marketGroup,target_countries:cfg.targetCountries,category:cfg.category,season:cfg.season,price_band:cfg.priceBand},coverage,score_table:rankingTable(scored),candidates:scored,source_records:records.map(({items,...r})=>({...r,item_count:items.length})),diagnostics};
      const fitted=fitEvidencePack(evidence,cfg.difyInputMaxChars);if(fitted.reductions.length)diagnostics.push(`Dify输入安全压缩:${[...new Set(fitted.reductions)].join('、')}`);
      try{
        const result=await callDify(cfg,{evidence_pack:fitted.text,market_context:JSON.stringify(evidence.market_context),factory_constraints:cfg.factoryConstraints,special_requirements:cfg.specialRequirements,version_contract:'P3商业试用；V1.1.0；稳定模式实际值为“稳定模式”'});difyMeta={attempts:result.attempts,validation_status:result.outputs.validation_status||'',quality_score:result.outputs.quality_score??null,sanitization_warnings:result.outputs.sanitization_warnings||''};
        const candidate=result.outputs.selection_report||'',difyGateOk=/可进入Node终审/.test(result.outputs.validation_status||'');
        if(difyGateOk){const nodeCheck=validateReport(candidate,scored,cfg,{difySucceeded:true});if(nodeCheck.passed){markdown=candidate;difySucceeded=true;}else{rejectedModelReport=result.outputs.raw_model_report||candidate;blockReason=`Node终审未通过:${nodeCheck.errors.join('；')}`;diagnostics.push(blockReason);markdown=evidenceFallback({runId,cfg,items:scored,sourceRecords:records,diagnostics,blockReason});}}
        else{rejectedModelReport=result.outputs.raw_model_report||candidate;blockReason=`Dify门禁未通过:${result.outputs.validation_errors||result.outputs.validation_status||'未知原因'}`;diagnostics.push(blockReason);markdown=evidenceFallback({runId,cfg,items:scored,sourceRecords:records,diagnostics,blockReason});}
      }catch(e){blockReason=`Dify写作失败:${e.message}`;diagnostics.push(blockReason);markdown=evidenceFallback({runId,cfg,items:scored,sourceRecords:records,diagnostics,blockReason});}
    }
    const validation=validateReport(markdown,scored,cfg,{difySucceeded});const exported=await exportRun(cfg,runId,{markdown,items:scored,validation,diagnostics:[...diagnostics,JSON.stringify(difyMeta)],rejectedModelReport});saveReport(db,runId,{commercialStatus:validation.commercialStatus,qualityScore:validation.qualityScore,path:exported.markdownPath,validation});finishRun(db,runId,validation.passed?'completed':'blocked',diagnostics);
    console.log(`[质量门禁] ${validation.commercialStatus}｜${validation.qualityScore}分｜commercial_ok=${validation.passed}`);validation.errors.forEach(x=>console.log(`[阻断] ${x}`));validation.warnings.forEach(x=>console.log(`[提醒] ${x}`));if(rejectedModelReport)console.log('[隔离] 被拒模型原稿已保存为 model-report-rejected.md');console.log(`[输出] ${exported.dir}`);if(cfg.strictCommercialGate&&!validation.passed)process.exitCode=2;
  }
}catch(e){diagnostics.push(e.stack||e.message);finishRun(db,runId,'failed',diagnostics);console.error(`[失败] ${e.message}`);process.exitCode=1;}finally{db.close();}
