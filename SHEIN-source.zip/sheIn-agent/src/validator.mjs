const REQUIRED=['## 1. 本轮结论','## 2. 候选款排序','## 3. Top候选逐款决策卡','## 4. 区域化跟版设计Brief','## 5. 小单验证方案','## 6. 暂不跟进与淘汰原因','## 7. 补数清单','## 8. 来源索引','## 9. 责任边界'];
export function validateReport(markdown,items,cfg,{difySucceeded=true,pipelineBlockers=[]}={}){
  const errors=[],warnings=[];const text=String(markdown||'');
  for(const section of REQUIRED)if(!text.includes(section))errors.push(`缺少章节:${section}`);
  if(/<think>|(?:^|\n)\s*思考过程[:：]/i.test(text))errors.push('包含不应展示的推理内容');
  const productLinks=items.filter(x=>x.link_type==='product'&&x.product_url).map(x=>x.product_url);const missing=productLinks.filter(url=>!text.includes(url));if(missing.length)errors.push(`缺少${missing.length}个商品详情直链`);
  for(const item of items.filter(x=>x.decision_grade))for(const [market,value] of Object.entries(item.market_scores||{}))if(!text.includes(String(value)))errors.push(`${item.title}缺少${market}评分${value}`);
  for(const item of items.filter(x=>!x.decision_grade&&x.title)){const escaped=String(item.title).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),block=text.match(new RegExp(`###\\s+${escaped}[\\s\\S]{0,700}?(?=\\n###|\\n##|$)`,'i'))?.[0]||'';if(/建议动作[:：]\s*(优先打样|小单测试)|建议(?:立即|优先)?打样/.test(block))errors.push(`发现级候选被错误推荐:${item.title}`);}
  if(text.length<1200)errors.push(`报告过短:${text.length}字符`);if(text.length>30000)warnings.push(`报告较长:${text.length}字符`);
  const low=items.filter(x=>x.evidence_completeness<cfg.minEvidenceCompleteness).length;if(low)warnings.push(`${low}款证据完整度低于${cfg.minEvidenceCompleteness}%`);
  const decisionGrade=items.filter(x=>x.decision_grade).length;if(decisionGrade<(cfg.minDecisionGradeCandidates||0))errors.push(`决策级候选不足:${decisionGrade}/${cfg.minDecisionGradeCandidates}`);
  errors.push(...pipelineBlockers.filter(Boolean));
  if(!difySucceeded)errors.push('商业写作链未成功或已按门禁跳过，当前仅为确定性证据报告');
  let score=100-errors.length*20-warnings.length*5;score=Math.max(0,score);const commercialStatus=errors.length===0&&score>=cfg.minReportScore?'可商业试用':'不可商业交付';
  return {passed:commercialStatus==='可商业试用',commercial_ok:commercialStatus==='可商业试用',commercialStatus,qualityScore:score,errors,warnings,decisionGradeCount:decisionGrade,checkedAt:new Date().toISOString()};
}
