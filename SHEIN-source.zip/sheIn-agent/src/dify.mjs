import { sleep } from './utils.mjs';

function timeoutSignal(ms){const c=new AbortController();const timer=setTimeout(()=>c.abort(new Error(`Dify timeout ${ms}ms`)),ms);return {signal:c.signal,clear:()=>clearTimeout(timer)};}
export async function callDify(cfg,inputs,{fetchImpl=fetch}={}){
  if(!cfg.difyApiKey)throw Object.assign(new Error('DIFY_API_KEY未配置'),{code:'DIFY_NOT_CONFIGURED'});
  let lastError;
  for(let attempt=0;attempt<=cfg.difyMaxRetries;attempt++){
    const t=timeoutSignal(cfg.difyTimeoutMs);
    try{
      const res=await fetchImpl(`${cfg.difyBaseUrl}/workflows/run`,{method:'POST',signal:t.signal,headers:{authorization:`Bearer ${cfg.difyApiKey}`,'content-type':'application/json'},body:JSON.stringify({inputs,response_mode:'blocking',user:'shein-p3-local'})});
      const body=await res.text();let json;try{json=JSON.parse(body);}catch{throw new Error(`Dify返回非JSON:${body.slice(0,160)}`);}
      if(!res.ok||json?.data?.status==='failed'){const err=new Error(`Dify ${res.status}:${json?.message||json?.data?.error||body.slice(0,160)}`);err.retryable=res.status===429||res.status>=500;throw err;}
      const outputs=json?.data?.outputs||json?.outputs||{};if(!outputs.selection_report)throw new Error('Dify输出缺少selection_report');return {outputs,raw:json,attempts:attempt+1};
    }catch(e){lastError=e;const retryable=e.name==='AbortError'||e.retryable||/timeout|fetch failed|ECONNRESET/i.test(e.message);if(!retryable||attempt>=cfg.difyMaxRetries)break;await sleep(800*2**attempt);}finally{t.clear();}
  }
  throw lastError||new Error('Dify调用失败');
}
