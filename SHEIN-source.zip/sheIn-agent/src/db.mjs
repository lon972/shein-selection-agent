import Database from 'better-sqlite3';
import path from 'node:path';
import fs from 'node:fs';

export function openDatabase(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const initialize = () => {
    const db = new Database(file);
    db.pragma('journal_mode = WAL'); db.pragma('busy_timeout = 5000');
    db.exec(`
    CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY, started_at TEXT, finished_at TEXT, status TEXT, stage TEXT, version TEXT, market_group TEXT, diagnostics TEXT);
    CREATE TABLE IF NOT EXISTS sources(id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, source_id TEXT, name TEXT, url TEXT, status TEXT, captured_at TEXT, error TEXT, item_count INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS evidence_items(id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, evidence_id TEXT, title TEXT, product_url TEXT, link_type TEXT, source_market TEXT, captured_at TEXT, score REAL, completeness INTEGER, action TEXT, payload_json TEXT, UNIQUE(run_id,evidence_id));
    CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, created_at TEXT, commercial_status TEXT, quality_score INTEGER, markdown_path TEXT, validation_json TEXT);
    CREATE INDEX IF NOT EXISTS idx_evidence_url ON evidence_items(product_url);
    CREATE INDEX IF NOT EXISTS idx_evidence_run ON evidence_items(run_id);
    `);
    const check=db.prepare('PRAGMA quick_check').get();if(String(Object.values(check||{})[0]||'').toLowerCase()!=='ok'){const error=new Error('database disk image is malformed');error.code='SQLITE_CORRUPT';db.close();throw error;}
    return db;
  };
  try{return initialize();}catch(error){
    if(!/SQLITE_CORRUPT|SQLITE_NOTADB|malformed|not a database/i.test(`${error.code||''} ${error.message||''}`))throw error;
    const stamp=new Date().toISOString().replace(/[:.]/g,'-'),backup=`${file}.corrupt-${stamp}`;
    try{fs.renameSync(file,backup);}catch{}
    for(const suffix of ['-wal','-shm'])try{fs.renameSync(`${file}${suffix}`,`${backup}${suffix}`);}catch{}
    console.warn(`[SQLite恢复] 检测到损坏，原文件已隔离：${backup}`);
    return initialize();
  }
}

export function startRun(db, runId, cfg) {
  db.prepare('INSERT INTO runs(id,started_at,status,stage,version,market_group,diagnostics) VALUES(?,?,?,?,?,?,?)').run(runId,new Date().toISOString(),'running',cfg.productStage,cfg.softwareVersion,cfg.marketGroup,'[]');
}
export function finishRun(db, runId, status, diagnostics=[]) { db.prepare('UPDATE runs SET finished_at=?,status=?,diagnostics=? WHERE id=?').run(new Date().toISOString(),status,JSON.stringify(diagnostics),runId); }
export function saveSource(db, runId, record) { db.prepare('INSERT INTO sources(run_id,source_id,name,url,status,captured_at,error,item_count) VALUES(?,?,?,?,?,?,?,?)').run(runId,record.id,record.name,record.url,record.status,record.capturedAt,record.error||'',record.items?.length||0); }
export function saveEvidence(db, runId, items) {
  const stmt=db.prepare('INSERT OR REPLACE INTO evidence_items(run_id,evidence_id,title,product_url,link_type,source_market,captured_at,score,completeness,action,payload_json) VALUES(?,?,?,?,?,?,?,?,?,?,?)');
  const tx=db.transaction(rows=>rows.forEach((x,i)=>stmt.run(runId,x.evidence_id||`E${String(i+1).padStart(3,'0')}`,x.title,x.product_url,x.link_type,x.source_market,new Date().toISOString(),x.score,x.evidence_completeness,x.action,JSON.stringify(x)))); tx(items);
}
export function saveReport(db, runId, report) { db.prepare('INSERT INTO reports(run_id,created_at,commercial_status,quality_score,markdown_path,validation_json) VALUES(?,?,?,?,?,?)').run(runId,new Date().toISOString(),report.commercialStatus,report.qualityScore,report.path,JSON.stringify(report.validation)); }
