export function fitEvidencePack(input,maxChars=50000){
  const evidence=structuredClone(input),reductions=[];const length=()=>JSON.stringify(evidence).length;
  while(length()>maxChars&&evidence.candidates?.length>3){evidence.candidates.pop();reductions.push('缩减候选款');}
  while(length()>maxChars&&evidence.diagnostics?.length>5){evidence.diagnostics.pop();reductions.push('缩减诊断');}
  while(length()>maxChars&&evidence.source_records?.length>2){evidence.source_records.pop();reductions.push('缩减来源诊断');}
  if(length()>maxChars&&evidence.candidates){evidence.candidates=evidence.candidates.map(x=>({evidence_id:x.evidence_id,title:x.title,product_url:x.product_url,link_type:x.link_type,source_market:x.source_market,score:x.score,action:x.action,evidence_completeness:x.evidence_completeness,score_breakdown:x.score_breakdown,evidence_date:x.evidence_date,evidence_note:String(x.evidence_note||'').slice(0,300),warnings:x.warnings}));reductions.push('候选字段压缩');}
  if(length()>maxChars){evidence.source_records=(evidence.source_records||[]).map(x=>({id:x.id,name:x.name,url:x.url,status:x.status,capturedAt:x.capturedAt,error:String(x.error||'').slice(0,120),item_count:x.item_count}));evidence.diagnostics=(evidence.diagnostics||[]).slice(0,5).map(x=>String(x).slice(0,160));reductions.push('来源与诊断字段压缩');}
  const text=JSON.stringify(evidence);if(text.length>maxChars)throw new RangeError(`结构化证据包在安全压缩后仍超限:${text.length}/${maxChars}`);return {text,evidence,reductions};
}
