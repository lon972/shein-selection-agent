import { spawnSync } from 'node:child_process';
for(const [name,args] of [['配置检查',['run','check']],['自动测试',['test']],['Mock全链路',['run','mock']]]){console.log(`\n[验收] ${name}`);const r=spawnSync('npm',args,{stdio:'inherit',shell:process.platform==='win32'});if(r.status!==0){console.error(`[验收失败] ${name}`);process.exit(r.status||1);}}
console.log('\nP3 V1.1.0本地自动验收通过。真实SHEIN访问和Dify在线调用仍以当前网络及账号为准。');
