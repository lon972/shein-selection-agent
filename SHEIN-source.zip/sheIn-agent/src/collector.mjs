import { cleanUrl, nowIso, safeText, sleep } from './utils.mjs';

function decodeHtml(s=''){return s.replace(/\\u002[fF]/g,'/').replace(/\\\//g,'/').replace(/&amp;/g,'&').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&lt;/g,'<').replace(/&gt;/g,'>');}
function shortError(error){return safeText(error?.message||error,240).split('\n')[0];}
function metricNumber(value){if(value===null||value===undefined||value==='')return null;const text=String(value).replace(/,/g,'').trim();const m=text.match(/(-?\d+(?:\.\d+)?)\s*([kKmM])?/);if(!m)return null;const factor=/k/i.test(m[2]||'')?1000:/m/i.test(m[2]||'')?1000000:1;return Number(m[1])*factor;}
function productUrl(raw,source,id='',name='Product'){
  let url=decodeHtml(String(raw||'')).trim();
  if(url&&url.startsWith('//'))url=`https:${url}`;else if(url&&url.startsWith('/'))url=new URL(url,source.url).toString();
  if(!url&&id){const slug=safeText(name,120).replace(/[^\p{L}\p{N}]+/gu,'-').replace(/^-|-$/g,'')||'Product';url=new URL(`/${encodeURIComponent(slug)}-p-${id}.html`,source.url).toString();}
  const clean=cleanUrl(url);return /-p-\d+\.html/i.test(clean)?clean:'';
}
function publicItem(source,{title,url,id='',text='',metrics={},method='html'}){
  const clean=productUrl(url,source,id,title),rank=metricNumber(metrics.bestseller_rank),sold=metricNumber(metrics.sold_recent),rating=metricNumber(metrics.rating),reviews=metricNumber(metrics.review_count);
  if(!clean)return null;return {title:safeText(decodeHtml(title)||'SHEIN公开候选款',300),product_url:clean,link_type:'product',source_market:source.market,category:'女装',rating:rating>=0&&rating<=5?rating:null,review_count:reviews>=0?reviews:null,sold_recent:sold>=0?sold:null,bestseller_rank:rank>=1?rank:null,evidence_date:new Date().toISOString().slice(0,10),evidence_note:`由${source.name}公开页面发现（${method}）；${safeText(text,260)||'销量、排名、评价和毛利需人工回查。'}`,source_id:source.id,captured_at:nowIso(),data_origin:'public_discovery',verification_status:'pending',extraction_method:method,confidence:method==='api_json'?0.72:method==='dom_anchor'?0.65:0.55};
}
function dedupe(items,maxItems){const map=new Map();for(const item of items){if(!item?.product_url)continue;const old=map.get(item.product_url);if(!old||Object.values(item).filter(v=>v!==null&&v!=='').length>Object.values(old).filter(v=>v!==null&&v!=='').length)map.set(item.product_url,item);}return [...map.values()].slice(0,maxItems);}

export function extractProducts(html,source,maxItems=12){
  const items=[];const linkRe=/<a[^>]+href=["']([^"']*-p-\d+\.html[^"']*)["'][^>]*(?:title=["']([^"']+)["'])?[^>]*>([\s\S]*?)<\/a>/gi;let m;
  while((m=linkRe.exec(html))&&items.length<maxItems*3){const visible=(m[2]||m[3].replace(/<[^>]+>/g,' ')).replace(/\s+/g,' ').trim();const rank=visible.match(/#(\d+)\s*Bestseller/i)?.[1],sold=visible.match(/([\d,.]+\s*[kKmM]?)\+?\s*sold/i)?.[1];items.push(publicItem(source,{title:m[2]||visible,url:m[1],text:visible,metrics:{bestseller_rank:rank,sold_recent:sold},method:'html_anchor'}));}
  const jsonUrlRe=/(?:https?:)?\\?\/\\?\/[^"'\s]+?-p-\d+\.html/gi;while((m=jsonUrlRe.exec(html))&&items.length<maxItems*5)items.push(publicItem(source,{url:m[0],method:'html_script'}));
  return dedupe(items.filter(Boolean),maxItems);
}

export function extractProductsFromJson(payload,source,maxItems=12){
  const items=[],stack=[payload],visited=new Set();let nodes=0;
  while(stack.length&&nodes<12000&&items.length<maxItems*4){const value=stack.pop();nodes++;if(!value||typeof value!=='object'||visited.has(value))continue;visited.add(value);if(Array.isArray(value)){for(const x of value.slice(0,300))stack.push(x);continue;}
    const id=value.goods_id??value.product_id??value.goodsId??value.productId;const title=value.goods_name??value.product_name??value.goodsName??value.productName??value.name??value.title;const url=value.goods_url??value.product_url??value.detail_url??value.goodsUrl??value.productUrl??value.url;
    if((id||url)&&title){const item=publicItem(source,{id:String(id||''),title:String(title),url,metrics:{rating:value.comment_rank_average??value.rating??value.star,sold_recent:value.sold_num??value.sale_num??value.sales,review_count:value.comment_num??value.review_count,bestseller_rank:value.rank??value.bestseller_rank},text:'动态商品接口字段；具体指标需打开详情页复核。',method:'api_json'});if(item)items.push(item);}
    for(const x of Object.values(value).slice(0,120))if(x&&typeof x==='object')stack.push(x);
  }
  return dedupe(items,maxItems);
}

export function extractProductsFromAnchors(anchors,source,maxItems=12){return dedupe((anchors||[]).map(x=>{const text=safeText(x.text,500),rank=text.match(/#(\d+)\s*Bestseller/i)?.[1],sold=text.match(/([\d,.]+\s*[kKmM]?)\+?\s*sold/i)?.[1];return publicItem(source,{title:x.title||text,url:x.href,text,metrics:{bestseller_rank:rank,sold_recent:sold},method:'dom_anchor'});}).filter(Boolean),maxItems);}

async function fetchHtml(url,timeoutMs){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);try{const res=await fetch(url,{signal:controller.signal,redirect:'follow',headers:{'user-agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/149 Safari/537.36','accept-language':'en-US,en;q=0.9'}});const text=await res.text();if(!res.ok)throw new Error(`HTTP ${res.status}`);if(text.length<500)throw new Error(`响应正文过短:${text.length}`);return {html:text,finalUrl:res.url};}finally{clearTimeout(timer);}}
async function browserCollect(source,url,timeoutMs,maxItems){
  const {chromium}=await import('playwright');const browser=await chromium.launch({headless:true});const apiItems=[];let captured=0;
  try{const page=await browser.newPage({locale:source.market==='TR'?'tr-TR':'en-US'});page.on('response',async response=>{try{if(captured>=30)return;const type=response.headers()['content-type']||'',length=Number(response.headers()['content-length']||0);if(!/json/i.test(type)||(length&&length>1500000)||!/product|goods|recommend|list|category/i.test(response.url()))return;captured++;const data=await response.json();apiItems.push(...extractProductsFromJson(data,source,maxItems));}catch{}});await page.goto(url,{waitUntil:'domcontentloaded',timeout:timeoutMs});for(let i=0;i<3;i++){await page.mouse.wheel(0,Math.max(900,await page.evaluate(()=>innerHeight)));await page.waitForTimeout(650);}const anchors=await page.locator('a[href*="-p-"]').evaluateAll(nodes=>nodes.slice(0,120).map(a=>({href:a.href,title:a.getAttribute('title')||a.querySelector('img')?.getAttribute('alt')||'',text:(a.innerText||a.textContent||'').trim()})));const html=await page.content();const items=dedupe([...apiItems,...extractProductsFromAnchors(anchors,source,maxItems),...extractProducts(html,source,maxItems)],maxItems);return {items,finalUrl:page.url(),methods:[...(apiItems.length?['api_json']:[]),...(anchors.length?['dom_anchor']:[]),'page_html']};}finally{await browser.close();}
}

export async function collectSource(source,cfg,{fixtureHtml=null,fixtureJson=null}={}){
  const record={...source,status:'failed',coverage_status:'access_failed',capturedAt:nowIso(),error:'',items:[],attempted_urls:[],extraction_methods:[]};
  if(fixtureHtml!==null||fixtureJson!==null){record.items=dedupe([...(fixtureJson?extractProductsFromJson(fixtureJson,source,cfg.maxItemsPerSource):[]),...(fixtureHtml?extractProducts(fixtureHtml,source,cfg.maxItemsPerSource):[])],cfg.maxItemsPerSource);record.status=record.items.length?'ok':'partial';record.coverage_status=record.items.length?'collected':'parse_empty';record.extraction_methods=['fixture'];return record;}
  const urls=[source.url,...(source.alternative_urls||[])].filter(Boolean);const errors=[];let reached=false;
  for(const url of urls){record.attempted_urls.push(url);for(let attempt=0;attempt<=cfg.collectMaxRetries;attempt++)try{const fetched=await fetchHtml(url,cfg.collectTimeoutMs);reached=true;const items=extractProducts(fetched.html,{...source,url:fetched.finalUrl},cfg.maxItemsPerSource);if(items.length){record.items=items;record.status='ok';record.coverage_status='collected';record.extraction_methods=['fetch_html'];return record;}errors.push(`${url}:fetch可访问但HTML无商品`);break;}catch(e){errors.push(`${url}:fetch:${shortError(e)}`);if(attempt<cfg.collectMaxRetries)await sleep(500*2**attempt);}}
  for(const url of urls){try{const result=await browserCollect(source,url,cfg.collectTimeoutMs,cfg.maxItemsPerSource);reached=true;if(result.items.length){record.items=result.items;record.status='ok';record.coverage_status='collected';record.extraction_methods=result.methods;return record;}errors.push(`${url}:浏览器可访问但DOM/接口均无商品`);}catch(e){const message=shortError(e);errors.push(`${url}:browser:${message}`);if(/Executable doesn't exist|browser executable/i.test(message))break;}}
  record.status=reached?'partial':'failed';record.coverage_status=reached?'parse_empty':'access_failed';record.error=errors.slice(-6).join('；');return record;
}

export async function collectAll(sourceConfig,cfg,options={}){
  const sources=(sourceConfig?.sources||[]).filter(x=>x.enabled!==false&&/^https?:\/\//.test(x.url)).sort((a,b)=>(a.priority||9)-(b.priority||9)).slice(0,cfg.maxActiveSources);const records=new Array(sources.length);let cursor=0;
  async function worker(){while(true){const index=cursor++;if(index>=sources.length)return;records[index]=await collectSource(sources[index],cfg,options);}}
  await Promise.all(Array.from({length:Math.min(cfg.collectConcurrency||2,sources.length||1)},worker));return records;
}
