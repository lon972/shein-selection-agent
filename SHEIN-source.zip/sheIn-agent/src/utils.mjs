import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';

export const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
export const nowIso = () => new Date().toISOString();
export const makeRunId = () => `run_${new Date().toISOString().replace(/[-:.TZ]/g, '').slice(0, 14)}_${crypto.randomBytes(3).toString('hex')}`;
export async function ensureDir(dir) { await fs.mkdir(dir, { recursive: true }); }
export async function readJson(file, fallback = null) { try { return JSON.parse(await fs.readFile(file, 'utf8')); } catch { return fallback; } }
export async function writeText(file, text) { await ensureDir(path.dirname(file)); await fs.writeFile(file, text, 'utf8'); }
export async function writeJson(file, value) { await writeText(file, JSON.stringify(value, null, 2)); }
export function cleanUrl(raw) {
  try {
    const url = new URL(String(raw || '').trim());
    if (!['http:', 'https:'].includes(url.protocol)) return '';
    for (const key of [...url.searchParams.keys()]) if (/^(utm_|ref$|referrer$)/i.test(key)) url.searchParams.delete(key);
    url.hash = ''; return url.toString();
  } catch { return ''; }
}
export function safeText(value, max = 1000) { return String(value ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').trim().slice(0, max); }
export function sha256(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }
export function csvEscape(v) { const s = String(v ?? ''); return /[",\n]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s; }
