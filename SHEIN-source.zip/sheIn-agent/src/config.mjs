import { config as loadEnv } from 'dotenv';
import path from 'node:path';
import { ROOT, resolveRoot } from './paths.mjs';

loadEnv({ path: path.join(ROOT, '.env'), quiet: true });
export const env = (name, fallback = '') => process.env[name] === undefined || process.env[name] === '' ? fallback : process.env[name];
export const intEnv = (name, fallback) => {
  const value = Number.parseInt(env(name, String(fallback)), 10);
  return Number.isFinite(value) ? value : fallback;
};
export const boolEnv = (name, fallback = false) => /^(1|true|yes|on)$/i.test(env(name, fallback ? 'true' : 'false'));

export function runtimeConfig() {
  const modeRaw = env('PERFORMANCE_MODE', '稳定模式');
  const performanceMode = /深度/.test(modeRaw) ? '深度模式' : '稳定模式';
  return {
    productStage: 'P3', softwareVersion: '1.1.0', performanceMode,
    marketGroup: env('MARKET_GROUP', '欧美+土耳其'),
    targetCountries: env('TARGET_COUNTRIES', '美国、英国、法国、德国、意大利、西班牙、土耳其'),
    category: env('CATEGORY', '女装连衣裙'), season: env('SEASON', ''), priceBand: env('PRICE_BAND', ''),
    factoryConstraints: env('FACTORY_CONSTRAINTS', ''), specialRequirements: env('SPECIAL_REQUIREMENTS', ''),
    difyBaseUrl: env('DIFY_BASE_URL', 'https://api.dify.ai/v1').replace(/\/$/, ''),
    difyApiKey: env('DIFY_API_KEY', ''), difyTimeoutMs: intEnv('DIFY_TIMEOUT_MS', 90000),
    difyMaxRetries: intEnv('DIFY_MAX_RETRIES', 2), difyInputMaxChars: intEnv('DIFY_INPUT_MAX_CHARS', 50000),
    collectTimeoutMs: intEnv('COLLECT_TIMEOUT_MS', 20000), collectMaxRetries: intEnv('COLLECT_MAX_RETRIES', 1), collectConcurrency: Math.max(1,Math.min(3,intEnv('COLLECT_CONCURRENCY',2))),
    maxActiveSources: intEnv('MAX_ACTIVE_SOURCES', 4), maxItemsPerSource: intEnv('MAX_ITEMS_PER_SOURCE', 12),
    maxCandidatesToDify: intEnv('MAX_CANDIDATES_TO_DIFY', 20),
    strictCommercialGate: boolEnv('STRICT_COMMERCIAL_GATE', true), minEvidenceCompleteness: intEnv('MIN_EVIDENCE_COMPLETENESS', 55), minDecisionGradeCandidates: intEnv('MIN_DECISION_GRADE_CANDIDATES',3),
    minReportScore: intEnv('MIN_REPORT_SCORE', 80),
    sqlitePath: resolveRoot(env('SQLITE_PATH', './data/evidence.sqlite')),
    outputDir: resolveRoot(env('OUTPUT_DIR', './output')), inputFile: resolveRoot(env('INPUT_FILE', './input/candidates.json')), inputCsvFile: resolveRoot(env('INPUT_CSV_FILE','./input/candidates.csv')),
    sourceFile: path.join(ROOT, 'config', 'sources.json')
  };
}
