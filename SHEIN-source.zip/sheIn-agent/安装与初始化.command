#!/bin/bash
cd "$(dirname "$0")"
registry="${NPM_REGISTRY:-https://registry.npmjs.org}"
ok=0
for attempt in 1 2 3; do
  echo "安装依赖：第${attempt}/3次，registry=${registry}"
  if npm install --registry="$registry"; then ok=1; break; fi
  echo "本次安装失败，将重试。请检查网络、代理和registry。"
done
if [ "$ok" -ne 1 ]; then
  echo "依赖安装失败。没有继续执行，也没有删除现有文件。"
  read -n 1 -s -r -p "按任意键关闭"
  exit 1
fi
npm run setup
echo "完成。请打开 .env 填写 DIFY_API_KEY，然后双击检查配置.command。"
read -n 1 -s -r -p "按任意键关闭"
