#!/bin/bash
cd "$(dirname "$0")"
npm run retry-writing
status=$?
printf "\n写作重试结束，状态码：%s\n" "${status}"
if [ "${status}" -eq 0 ]; then
  echo "结果：重试报告通过门禁，原报告已备份。"
else
  echo "结果：重试仍未通过，原报告没有被覆盖。"
fi
read -n 1 -s -r -p "按任意键关闭"
exit $status
