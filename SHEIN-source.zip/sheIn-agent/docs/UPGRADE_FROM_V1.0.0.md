# 从P3 V1.0.0升级到P3 V1.1.0

## 必须整体替换

不要只替换`src/collector.mjs`。本次同时改变采集结构、评分字段、Dify变量、报告门禁和输入模板，必须使用完整V1.1.0目录。

## 步骤

1. 保留旧V1.0.0目录，不覆盖，作为回滚版本。
2. 解压V1.1.0到新目录。
3. 不要复制旧`node_modules`。
4. 双击V1.1.0的`安装与初始化.command`。
5. 导入新的`SHEIN女装选品与跟版决策Agent_P3_V1.1.0.yml`。
6. 发布新工作流，获取新Dify API Key。
7. 将旧`.env`中的Dify地址、API Key以外业务配置逐项迁移；推荐直接以新`.env.example`为基础。
8. 确认：

```dotenv
MARKET_GROUP=欧美+土耳其
TARGET_COUNTRIES=美国、英国、法国、德国、意大利、西班牙、土耳其
INPUT_CSV_FILE=./input/candidates.csv
MIN_DECISION_GRADE_CANDIDATES=3
```

9. 把需要继续使用的候选款整理进新`input/candidates.csv`，补上核验状态和欧美/土耳其适配字段。
10. 运行`检查配置.command`和`本地自我验收.command`。

## 不建议直接复制

- 旧`node_modules`；
- 旧Dify YML；
- 旧`input/candidates.json`中的演示数据；
- 旧`.env`整文件覆盖新模板。

旧`output`和`data/evidence.sqlite`可留在V1.0.0目录作为历史记录。V1.1.0建议使用新证据库，避免演示数据混入新决策级统计。

