#!/bin/bash
cd "$(dirname "$0")"
npm run check
read -n 1 -s -r -p "按任意键关闭"
